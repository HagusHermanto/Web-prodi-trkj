<!-- Scripts -->
<!-- Bootstrap core JavaScript -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>

<script src="<?= base_url() ?>template/tema-trkj/vendor/jquery/jquery.min.js"></script>
<script src="<?= base_url() ?>template/tema-trkj/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<script src="<?= base_url() ?>template/tema-trkj/assets/js/isotope.min.js"></script>
<script src="<?= base_url() ?>template/tema-trkj/assets/js/owl-carousel.js"></script>
<script src="<?= base_url() ?>template/tema-trkj/assets/js/lightbox.js"></script>
<script src="<?= base_url() ?>template/tema-trkj/assets/js/tabs.js"></script>
<script src="<?= base_url() ?>template/tema-trkj/assets/js/video.js"></script>
<script src="<?= base_url() ?>template/tema-trkj/assets/js/slick-slider.js"></script>
<script src="<?= base_url() ?>template/tema-trkj/assets/js/custom.js"></script>

<!-- DataTables JavaScript -->
<script src="<?= base_url() ?>template/tema-trkj/js/dataTables/jquery.dataTables.min.js"></script>
<script src="<?= base_url() ?>template/tema-trkj/js/dataTables/dataTables.bootstrap.min.js"></script>
<script src="<?= base_url() ?>template/tema-trkj/js/dataTables/dataTables.responsive.js"></script>
<script>
	//according to loftblog tut
	$('.nav li:first').addClass('active');

	var showSection = function showSection(section, isAnimate) {
		var
			direction = section.replace(/#/, ''),
			reqSection = $('.section').filter('[data-section="' + direction + '"]'),
			reqSectionPos = reqSection.offset().top - 0;

		if (isAnimate) {
			$('body, html').animate({
					scrollTop: reqSectionPos
				},
				800);
		} else {
			$('body, html').scrollTop(reqSectionPos);
		}

	};

	var checkSection = function checkSection() {
		$('.section').each(function() {
			var
				$this = $(this),
				topEdge = $this.offset().top - 80,
				bottomEdge = topEdge + $this.height(),
				wScroll = $(window).scrollTop();
			if (topEdge < wScroll && bottomEdge > wScroll) {
				var
					currentId = $this.data('section'),
					reqLink = $('a').filter('[href*=\\#' + currentId + ']');
				reqLink.closest('li').addClass('active').
				siblings().removeClass('active');
			}
		});
	};

	$('.main-menu, .responsive-menu, .scroll-to-section').on('click', 'a', function(e) {
		e.preventDefault();
		showSection($(this).attr('href'), true);
	});

	$(window).scroll(function() {
		checkSection();
	});
</script>
</body>

</body>

</html>