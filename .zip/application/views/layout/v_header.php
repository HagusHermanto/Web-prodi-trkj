  <!-- Sub Header -->
  <div class="sub-header">
  	<div class="container">
  		<div class="row">
  			<div class="col-lg-8 col-sm-8">
  				<div class="left-content">
  					<p>Teknologi Rekayasa Komputer Jaringan <em>(TRKJ)</em> Aksi Koneksi</p>
  				</div>
  			</div>
  			<div class="col-lg-4 col-sm-4">
  				<div class="right-icons">
  					<ul>
  						<li><a href="#"><i class="fa fa-instagram"></i></a></li>
  						<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
  					</ul>
  				</div>
  			</div>
  		</div>
  	</div>
  </div>