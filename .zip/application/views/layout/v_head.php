<!DOCTYPE html>
<html lang="en">

<head>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="">
	<meta name="author" content="TemplateMo">
	<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">

	<title>Website TRKJ</title>

	<!-- Bootstrap core CSS -->
	<link href=" <?= base_url() ?>template/tema-trkj/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


	<!-- Additional CSS Files -->
	<link rel="stylesheet" href="<?= base_url() ?>template/tema-trkj/assets/css/fontawesome.css">
	<link rel="stylesheet" href="<?= base_url() ?>template/tema-trkj/assets/css/templatemo-edu-meeting.css">
	<link rel="stylesheet" href="<?= base_url() ?>template/tema-trkj/assets/css/owl.css">
	<link rel="stylesheet" href="<?= base_url() ?>template/tema-trkj/assets/css/lightbox.css">

	<!-- DataTables CSS -->
	<link href="<?= base_url() ?>template/tema-trkj/css/dataTables/dataTables.bootstrap.css" rel="stylesheet">

	<!-- DataTables Responsive CSS -->
	<link href="<?= base_url() ?>template/tema-trkj/css/dataTables/dataTables.responsive.css" rel="stylesheet">
	<!--

TemplateMo 569 Edu Meeting

https://templatemo.com/tm-569-edu-meeting

-->
</head>