<!-- ***** Main Banner Area Start ***** -->
<section class="section main-banner" id="top" data-section="section1">
	<video autoplay muted loop id="bg-video">
		<source src="<?= base_url() ?>template/tema-trkj/assets/images/course-video.mp4" type="video/mp4" />
	</video>

	<div class="video-overlay header-text">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="caption">
						<h6>Hello Students</h6>
						<h2>Welcome to TRKJ</h2>
						<p>Let's study at TRKJ, because at TRKJ you will get knowledge of Computer Networks, Programmers, Multimedia and Robotics. And TRKJ students also have the opportunity to study abroad with a student exchange program.</p>
						<div class="main-button-red">
							<div><a href="https://spmb.bunghatta.ac.id/">Ayo Gabung di TRKJ!</a></div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- ***** Main Banner Area End ***** -->

<section class="services">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="owl-service-item owl-carousel">

					<div class="item">
						<div class="icon">
							<img src="<?= base_url() ?>template/tema-trkj/assets/images/service-icon-01.png" alt="">
						</div>
						<div class="down-content">
							<h4>Peluang karir yang baik di berbagai industri.</h4>
							<p></p>
						</div>
					</div>

					<div class="item">
						<div class="icon">
							<img src="<?= base_url() ?>template/tema-trkj/assets/images/service-icon-02.png" alt="">
						</div>
						<div class="down-content">
							<h4>Kemampuan yang beragam dalam TRKJ.</h4>
							<p></p>
						</div>
					</div>

					<div class="item">
						<div class="icon">
							<img src="<?= base_url() ?>template/tema-trkj/assets/images/service-icon-03.png" alt="">
						</div>
						<div class="down-content">
							<h4>Tantangan intelektual yang menarik.</h4>
							<p></p>
						</div>
					</div>

					<div class="item">
						<div class="icon">
							<img src="<?= base_url() ?>template/tema-trkj/assets/images/service-icon-02.png" alt="">
						</div>
						<div class="down-content">
							<h4>Permintaan tenaga kerja yang tinggi di bidang TRKJ.</h4>
							<p></p>
						</div>
					</div>

					<div class="item">
						<div class="icon">
							<img src="<?= base_url() ?>template/tema-trkj/assets/images/service-icon-03.png" alt="">
						</div>
						<div class="down-content">
							<h4></h4>
							<h6>Pengembangan keterampilan praktis melalui proyek dan eksperimen.</h6>
						</div>
					</div>

				</div>
			</div>
		</div>
	</div>
</section>

<section class="upcoming-meetings" id="meetings">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="section-heading">
					<h2>Berita Terbaru</h2>
				</div>
			</div>

			<div class="col-lg-12">
				<div class="row">
					<?php foreach ($berita as $key => $value) { ?>
						<div class="col-lg-4 course_col">
							<div class="meeting-item">
								<div class="thumb">
									<div class="price">
										<span><?= $value->tgl_berita ?></span>
									</div>
									<div class=""><img src="<?= base_url('gambar_berita/' . $value->gambar_berita) ?>" height="200px" width="100%"></div>
								</div>
								<div class="down-content">
									<div class="date">
										<h6><?= $value->nama_user ?><span></span></h6>
									</div>
									<h4 class="course_title"><a href="<?= base_url('home/detail_berita/' . $value->slug_berita) ?>"><?= substr(strip_tags($value->judul_berita), 0, 25) ?>...</a></h4>
									<p><?= substr(strip_tags($value->isi_berita), 0, 100) ?>..</p>
								</div>
							</div>
						</div>
					<?php } ?>
				</div>
				<div class="col-lg-12">
					<div class="main-button-red text-center">
						<a href="<?= base_url('home/berita') ?>">Lihat Semua Berita</a>
					</div>
				</div>
			</div>

		</div>
	</div>
</section>

<section class="apply-now" id="apply">
	<div class="container">
		<div class="row">
			<div class="col-lg-6 align-self-center">
				<div class="row">
					<div class="col-lg-12">
						<div class="item">
							<h3>Fasilitas di Prodi TRKJ</h3>
							<p>Prodi Teknologi Rekayasa Komputer Jaringan (TRKJ) umumnya menyediakan berbagai fasilitas untuk mendukung kegiatan pembelajaran dan penelitian di bidang komputer dan jaringan. Beberapa fasilitas yang biasanya tersedia di jurusan ini antara lain:</p>
							<div class="main-button-red">
								<div><a href="<?= base_url('home/fasilitas') ?>">Lihat Selengkapnya</a></div>
							</div>
						</div>
					</div>
					<div class="col-lg-12">
						<div class="item">
							<h3>Kenapa Harus Kuliah di TRKJ</h3>
							<p>Dalam program studi TRKJ, Anda akan mempelajari konsep dasar tentang jaringan komputer, pengaturan perangkat jaringan, keamanan jaringan, pemecahan masalah terkait jaringan, pemrograman web, pemrograman android, robotika, IOT dan multimedia. Anda akan diberikan pengetahuan tentang protokol jaringan, administrasi jaringan, pemrograman jaringan, serta teknologi terkini dalam bidang jaringan komputer.</p>
							<div class="main-button-yellow">
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-6">
				<div class="accordions is-first-expanded">
					<article class="accordion">
						<div class="accordion-head">
							<span>Peluang Karir yang Baik</span>
							<span class="icon">
								<i class="icon fa fa-chevron-right"></i>
							</span>
						</div>
						<div class="accordion-body">
							<div class="content">
								<p> TRKJ adalah bidang yang berkembang pesat, terutama dengan perkembangan teknologi informasi (website, android, software dll) dan komunikasi yang terus berlanjut. Lulusan TRKJ memiliki peluang karir yang baik di berbagai industri, termasuk teknologi, telekomunikasi, perbankan, dan perusahaan layanan IT.</p>
							</div>
						</div>
					</article>
					<article class="accordion">
						<div class="accordion-head">
							<span>Permintaan Tinggi</span>
							<span class="icon">
								<i class="icon fa fa-chevron-right"></i>
							</span>
						</div>
						<div class="accordion-body">
							<div class="content">
								<p>Ketergantungan kita pada teknologi semakin meningkat, dan sebagai hasilnya, permintaan tenaga kerja yang terampil di bidang TRKJ terus meningkat. Lulusan TRKJ biasanya dicari oleh perusahaan-perusahaan yang membutuhkan ahli dalam merancang, mengembangkan, dan mengelola jaringan komputer.</p>
							</div>
						</div>
					</article>
					<article class="accordion">
						<div class="accordion-head">
							<span>Kemampuan yang Beragam</span>
							<span class="icon">
								<i class="icon fa fa-chevron-right"></i>
							</span>
						</div>
						<div class="accordion-body">
							<div class="content">
								<p>Program studi TRKJ memberikan pengetahuan dan keterampilan yang luas dalam berbagai aspek teknologi dan jaringan komputer. Anda akan mempelajari topik seperti desain jaringan, administrasi sistem, keamanan jaringan, pemrograman, dan manajemen proyek. Dengan demikian, Anda akan memiliki kemampuan yang beragam dan dapat bekerja di berbagai peran dan tanggung jawab.</p>
							</div>
						</div>
					</article>
					<article class="accordion last-accordion">
						<div class="accordion-head">
							<span>Tantangan yang Menarik</span>
							<span class="icon">
								<i class="icon fa fa-chevron-right"></i>
							</span>
						</div>
						<div class="accordion-body">
							<div class="content">
								<p>Tantangan yang Menarik: Bidang TRKJ sering kali melibatkan pemecahan masalah kompleks dan tantangan teknis. Anda akan diajarkan cara merancang, membangun, dan memecahkan masalah pada jaringan komputer. Bagi mereka yang menyukai tantangan intelektual, ini dapat menjadi kelebihan besar.</p>
							</div>
						</div>
					</article>
					<article class="accordion last-accordion">
						<div class="accordion-head">
							<span>Pengembangan Keterampilan Praktis</span>
							<span class="icon">
								<i class="icon fa fa-chevron-right"></i>
							</span>
						</div>
						<div class="accordion-body">
							<div class="content">
								<p>Program studi TRKJ sering kali memiliki pendekatan yang praktis, yang memungkinkan mahasiswa untuk mengembangkan keterampilan teknis secara langsung. Anda akan terlibat dalam proyek-proyek nyata dan melakukan eksperimen di laboratorium komputer, yang membantu memperkuat pemahaman teoritis Anda dan mempersiapkan Anda untuk dunia kerja.</p>
							</div>
						</div>
					</article>
				</div>
			</div>
		</div>
	</div>
</section>

<!-- <section class="our-courses" id="courses">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="section-heading">
					<h2>Dosen TRKJ</h2>
				</div>
			</div>
			<div class="col-lg-12">
				<div class="owl-courses-item owl-carousel">
					<div class="item">
						<img src="template/tema-trkj/assets/images/course-01.jpg" alt="Course One">
						<div class="down-content">
							<h4>Morbi tincidunt elit vitae justo rhoncus</h4>
							<div class="info">
								<div class="row">
									<div class="col-8">
										<ul>
											<li><i class="fa fa-star"></i></li>
											<li><i class="fa fa-star"></i></li>
											<li><i class="fa fa-star"></i></li>
											<li><i class="fa fa-star"></i></li>
											<li><i class="fa fa-star"></i></li>
										</ul>
									</div>
									<div class="col-4">
										<span>$160</span>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section> -->

<section class="our-facts">
	<div class="container">
		<div class="row">
			<div class="col-lg-6">
				<div class="row">
					<div class="col-lg-12">
						<h2>Beberapa Fakta Tentang Prodi TRKJ</h2>
					</div>
					<div class="col-lg-6">
						<div class="row">
							<div class="col-12">
								<div class="count-area-content percentage">
									<div class="count-digit">70</div>
									<div class="count-title">Praktikum</div>
								</div>
							</div>

							<div class="col-12">
								<div class="count-area-content percentage">
									<div class="count-digit">30</div>
									<div class="count-title">Teori</div>
								</div>
							</div>
						</div>
					</div>
					<!-- <div class="col-lg-6">
						<div class="row">
							<div class="col-12">
								<div class="count-area-content new-students">
									<div class="count-digit">2345</div>
									<div class="count-title">New Students</div>
								</div>
							</div>
							<div class="col-12">
								<div class="count-area-content">
									<div class="count-digit">32</div>
									<div class="count-title">Awards</div>
								</div>
							</div>
						</div>
					</div> -->
				</div>
			</div>
			<div class="col-lg-6 align-self-center">
				<div class="video">
					<a href="https://www.youtube.com/@trkjbunghatta8178/featured" target="_blank"><img src="<?= base_url() ?>template/tema-trkj/assets/images/play-icon.png" alt=""></a>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="contact-us" id="contact">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 align-self-center">
				<div class="row">
					<div class="col-lg-12">
						<form id="contact" action="" method="post">
							<div class="row">
								<div class="col-lg-12">
									<h2>Hubungi Kami</h2>
								</div>
								<div class="col-lg-4">
									<fieldset>
										<input name="name" type="text" id="name" placeholder="YOURNAME...*" required="">
									</fieldset>
								</div>
								<div class="col-lg-4">
									<fieldset>
										<input name="email" type="text" id="email" pattern="[^ @]*@[^ @]*" placeholder="YOUR EMAIL..." required="">
									</fieldset>
								</div>
								<div class="col-lg-4">
									<fieldset>
										<input name="subject" type="text" id="subject" placeholder="SUBJECT...*" required="">
									</fieldset>
								</div>
								<div class="col-lg-12">
									<fieldset>
										<textarea name="message" type="text" class="form-control" id="message" placeholder="YOUR MESSAGE..." required=""></textarea>
									</fieldset>
								</div>
								<div class="col-lg-12">
									<fieldset>
										<button type="submit" id="form-submit" class="button">SEND MESSAGE NOW</button>
									</fieldset>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>

		</div>
	</div>

	<div class="footer">
		<p>
			&copy <script>
				document.write(new Date().getFullYear())
			</script> Teknolgi Rekayasa Komputer Jaringan
		</p>
	</div>
</section>